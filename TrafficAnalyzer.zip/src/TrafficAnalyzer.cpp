#include "TrafficAnalyzer.h"
#include <fstream>
#include <sstream>

void TrafficAnalyzer::load_data(const std::string &filename) {
    std::ifstream file(filename);
    std::string line;

    while (std::getline(file, line)) {
        std::stringstream ss(line);
        std::string id, type, timestamp;
        double speed;

        std::getline(ss, timestamp, ',');
        std::getline(ss, id, ',');
        std::getline(ss, type, ',');
        ss >> speed;

        vehicles.push_back(Vehicle(id, type, speed, timestamp));
    }
}

int TrafficAnalyzer::count_vehicles() const {
    return vehicles.size();
}

double TrafficAnalyzer::calculate_average_speed() const {
    double total_speed = 0;
    for (const auto &vehicle : vehicles) {
        total_speed += vehicle.getSpeed();
    }
    return total_speed / vehicles.size();
}

std::map<std::string, int> TrafficAnalyzer::classify_vehicles() const {
    std::map<std::string, int> classification;
    for (const auto &vehicle : vehicles) {
        classification[vehicle.getType()]++;
    }
    return classification;
}
